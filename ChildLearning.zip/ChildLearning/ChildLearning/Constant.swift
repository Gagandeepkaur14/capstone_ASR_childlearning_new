//
//  Constant.swift
//  ChildLearning
//
//  Created by Rakinder on 11/04/21.
//

import UIKit

class Constant: NSObject {
   static let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    struct FirebaseData {
        static let Numbers = "Numbers"
        static let User = "User"
       static let Alphabets = "Alphabets"
        static let Words = "Words"
    }
}
