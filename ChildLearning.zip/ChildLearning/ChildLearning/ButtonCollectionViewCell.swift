//
//  ButtonCollectionViewCell.swift
//  ChildLearning
//
//

import UIKit

class ButtonCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgV: UIImageView!
}
